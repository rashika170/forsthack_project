# TODO App In Flutter !

This repo contains  **Source Code** of a TODO App coded in Flutter. 
We have used  **SQFLITE** database to store persistant data.


# Tutorial

[UI](https://youtu.be/M3IwPbjOXmw)

[The Backend](https://youtu.be/BDWZlUyQZF0)

## ScreenShots

![Screen](assets/screenshots/screen.png)
![Screen](assets/screenshots/alert.png)